/**
* @file light_system.c
* @author www.tuya.com
* @brief 
* @version 0.1
* @date 2021-08-19
*
* @copyright Copyright (c) tuya.inc 2021
*
*/

#include "tuya_iot_com_api.h"
#include "uni_log.h"

#include "tuya_device.h"
#include "light_system.h"
#include "dp_process.h"

#include "FreeRTOS.h"
#include "task.h"
#include "uni_thread.h"
/***********************************************************
*************************micro define***********************
***********************************************************/


/***********************************************************
***********************typedef define***********************
***********************************************************/


/***********************************************************
***********************variable define**********************
***********************************************************/
STATIC LED_STATUS_E cur_light_status = LIGHT_OFF;
STATIC PIR_STATUS_E cur_pir_status = PIR_OFF;
STATIC PIR_STATUS_E last_pir_status = PIR_OFF;
STATIC MODE_STATUS_E cur_mode_status = AUTO_OFF;
/***********************************************************
***********************function define**********************
***********************************************************/


/**
* @brief need quick start tasks

* @return none
*/
VOID_T fast_boot(VOID_T)
{
    OPERATE_RET op_ret = OPRT_OK;
    op_ret = light_init();
    if (op_ret != OPRT_OK) {
        PR_ERR("fast boot light init error, %d", op_ret);
        return;
    }
    return;
}

/**
* @brief light gpio init
*
* @return none
*/
OPERATE_RET light_init(VOID_T)
{
    OPERATE_RET op_ret = OPRT_OK;

    /* light pin set output */
    op_ret = tuya_gpio_inout_set(LIGHT_PIN, FALSE);
    if (op_ret != OPRT_OK) {
        PR_ERR("light init gpio set inout error!");
        return op_ret;
    }

    /* light pin mode set pullup */
    op_ret = tuya_gpio_mode_set(LIGHT_PIN, TY_GPIO_PULLDOWN);
    if (op_ret != OPRT_OK) {
        PR_ERR("light init gpio mode set error!");
        return op_ret;
    }
    
    /* light off */
    op_ret = set_light_status(LIGHT_OFF);
    if (op_ret != OPRT_OK) {
        PR_ERR("light init light on error!");
        return op_ret;
    }
    return op_ret;
}

/**
* @brief light on
*
* @return none
*/
STATIC OPERATE_RET light_on(VOID_T)
{
    OPERATE_RET op_ret = OPRT_OK;

    /* pin set low level, light on */
    op_ret = tuya_gpio_write(LIGHT_PIN, TRUE);
    if (op_ret != OPRT_OK) {
        PR_ERR("light on error!");
        return op_ret;
    }

    cur_light_status = LIGHT_ON;

    return op_ret;
}

/**
* @brief light off
*
* @return none
*/
STATIC OPERATE_RET light_off(VOID_T)
{
    OPERATE_RET op_ret = OPRT_OK;

    /* pin set high level, light off */
    op_ret = tuya_gpio_write(LIGHT_PIN, FALSE);
    if (op_ret != OPRT_OK) {
        PR_ERR("light off error!");
        return op_ret;
    }

    cur_light_status = LIGHT_OFF;

    return op_ret;
}

/**
* @brief set light status
*
* @param[in] status: LIGHT_ON or LIGHT_OFF
* @return none
*/
OPERATE_RET set_light_status(LED_STATUS_E status)
{
    OPERATE_RET op_ret = OPRT_OK;

    if (status == LIGHT_ON) {
        op_ret = light_on();
        if (op_ret != OPRT_OK) {
            return op_ret;
        }
    } else {
        light_off();
        if (op_ret != OPRT_OK) {
            return op_ret;
        }
    }

    return op_ret;
}

/**
* @brief set mode status
*
* @param[in] status: AUTO_ON or AUTO_OFF
* @return none
*/
OPERATE_RET set_mode_status(MODE_STATUS_E status)
{
    OPERATE_RET op_ret = OPRT_OK;

        cur_mode_status = status;
        if (op_ret != OPRT_OK) {
            return op_ret;
        }

    return op_ret;
}

/**
* @brief get light status
*
* @return light status: LIGHT_ON or LIGHT_OFF
*/
LED_STATUS_E get_light_status(VOID_T)
{
    return cur_light_status;
}

/**
* @brief get pir status
*
* @return pir status: PIR_ON or PIR_OFF
*/
PIR_STATUS_E get_pir_status(VOID_T)
{
    return cur_pir_status;
}

/**
* @brief get mode status
*
* @return mode status: AUTO_ON or AUTO_OFF
*/
MODE_STATUS_E get_mode_status(VOID_T)
{
    return cur_mode_status;
}


/***********************************************************
 *   Function:  get_pir_sensor_value
 *   Input:     none
 *   Output:    none
 *   Return:    none
 *   Notice:    得到并上传人体的数据
 ***********************************************************/
VOID_T get_pir_sensor_value(VOID_T)
{
    cur_pir_status = tuya_gpio_read(PIR_PIN);
    OPERATE_RET op_ret = OPRT_OK;
    if (last_pir_status != cur_pir_status) {
        last_pir_status = cur_pir_status;
        //如果AUTO状态为ON，则同步Light IO状态，否则只上报PIR人体状态
        if (AUTO_ON == cur_mode_status) {
            //PR_DEBUG(" AUTO MODE ON");
            op_ret = set_light_status(cur_pir_status);
            //PR_DEBUG("pir AUTO light~~!!!!!!!!!!!!!!");
              if (op_ret != OPRT_OK) {
                  PR_ERR("pir AUTO light errorrrrrrrrrrr!");
              }
        
        } else {
        PR_ERR(" AUTO MODE OFF");
        }

    update_all_dp();
    
    }
    return;
}

 /***********************************************************
 *   Function:  pir_data_task
 *   Input:     none
 *   Output:    none
 *   Return:    none
 *   Notice:    获取人体传感器状态任务
 ***********************************************************/
VOID_T pir_data_task(VOID_T)
{
    while (1) {
        get_pir_sensor_value();
        tuya_hal_system_sleep(200);
    }
}

/***********************************************************
 *   Function:  pir_device_init
 *   Input:     none
 *   Output:    none
 *   Return:    none
 *   Notice:    人体感应初始化
 ***********************************************************/
VOID_T pir_device_init(VOID_T)
{
    INT_T opRet = OPRT_OK;

    /* 人体传感器相关外设初始化 */
    tuya_gpio_inout_set(PIR_PIN, TRUE);
    PR_DEBUG("PIR_PIN INIT OK!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

    tuya_hal_thread_create(NULL, "pir sensor data", 512*4, TRD_PRIO_5, pir_data_task, NULL);
}